-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 27 Bulan Mei 2021 pada 09.24
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bismillah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_barang`
--

CREATE TABLE `tbl_barang` (
  `barang_id` varchar(15) NOT NULL,
  `barang_nama` varchar(150) DEFAULT NULL,
  `barang_satuan` varchar(30) DEFAULT NULL,
  `barang_harpok` double DEFAULT NULL,
  `barang_harjul` double DEFAULT NULL,
  `barang_harjul_grosir` double DEFAULT NULL,
  `barang_stok` int(11) DEFAULT 0,
  `barang_min_stok` int(11) DEFAULT 0,
  `barang_tgl_input` timestamp NULL DEFAULT current_timestamp(),
  `barang_tgl_last_update` datetime DEFAULT NULL,
  `barang_kategori_id` int(11) DEFAULT NULL,
  `barang_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_barang`
--

INSERT INTO `tbl_barang` (`barang_id`, `barang_nama`, `barang_satuan`, `barang_harpok`, `barang_harjul`, `barang_harjul_grosir`, `barang_stok`, `barang_min_stok`, `barang_tgl_input`, `barang_tgl_last_update`, `barang_kategori_id`, `barang_user_id`) VALUES
('PJ000001', 'ID Band Dewasa Pink', 'PCS', 65000, 65000, 65000, 17, 1, '2021-05-07 03:14:52', '2021-05-27 13:59:23', 46, 5),
('PJ000002', 'Spuit 10cc OM', 'Kotak', 86250, 86250, 86250, 7, 2, '2021-05-07 03:15:42', NULL, 46, 8),
('PJ000003', 'Disp. Syringe 3ml Lock (23GX1 1/4\") BLS E-', 'PCS', 828, 828, 828, 10, 2, '2021-05-07 03:16:33', NULL, 46, 8),
('PJ000004', 'Infuset Y-Injection site', 'PCS', 7418, 7418, 7418, 6, 2, '2021-05-07 03:17:13', NULL, 46, 8),
('PJ000005', 'Safelet cath/teflon 24GX1\"', 'PCS', 7418, 7418, 7418, 10, 2, '2021-05-07 03:17:54', NULL, 46, 8),
('PJ000006', 'Kassa Lipat Medikasi', 'Pack', 122000, 122000, 122000, 12, 2, '2021-05-07 03:34:21', NULL, 46, 8),
('PJ000007', 'Kassa Lipat OK ', 'Pack', 122000, 122000, 122000, 12, 2, '2021-05-07 03:34:57', NULL, 46, 8),
('PJ000008', 'Atramat Chromic 2-0 TP37mm 90cm', 'PCS', 65000, 65000, 65000, 12, 3, '2021-05-07 03:35:26', NULL, 46, 8),
('PJ000009', 'Atramat Silk 2 TP 40mm', 'PCS', 50000, 50000, 50000, 12, 2, '2021-05-07 03:35:52', NULL, 46, 8),
('PJ000010', 'Atramat PGA 2-0 RC 40mm 90cm', 'PCS', 90000, 90000, 90000, 7, 2, '2021-05-07 03:36:16', NULL, 46, 8),
('PJ000011', 'Atramat Plain 0 TP 40mm 75cm', 'PCS', 42500, 42500, 42500, 8, 2, '2021-05-07 03:36:39', NULL, 46, 8),
('PJ000012', 'Atramat PPL 2-0 RC 24mm', 'PCS', 80000, 80000, 80000, 12, 2, '2021-05-07 03:37:02', NULL, 46, 8),
('PJ000013', 'Surgisilk 2-0 TP26', 'PCS', 50000, 50000, 50000, 9, 2, '2021-05-07 03:37:28', NULL, 46, 8),
('PJ000014', 'Spalk Tali M', 'PCS', 11000, 11000, 11000, 12, 2, '2021-05-07 03:37:49', NULL, 46, 8),
('PJ000015', 'Jarum Mani MH28', 'Pack', 90000, 90000, 90000, 6, 2, '2021-05-07 03:38:15', NULL, 46, 8),
('PJ000016', 'Jarum Mani MH32', 'Pack', 90000, 90000, 90000, 9, 2, '2021-05-07 03:38:41', NULL, 46, 8),
('PJ000017', 'Jarum Mani MH36', 'Pack', 90000, 90000, 90000, 12, 2, '2021-05-07 03:39:04', NULL, 46, 8),
('PJ000018', 'Jarum Mani MH40', 'Pack', 90000, 90000, 90000, 23, 2, '2021-05-07 03:39:32', NULL, 46, 8),
('PJ000019', 'Tensocrepe 3\"', 'Roll', 65000, 65000, 65000, 12, 2, '2021-05-07 03:40:01', NULL, 46, 8),
('PJ000020', 'Jarum Mani MH55', 'PCS', 8250, 8250, 8250, 8, 2, '2021-05-07 03:40:36', NULL, 46, 8),
('PJ000021', 'Low Temperature Cautery Fine Tip', 'PCS', 400000, 400000, 400000, 12, 2, '2021-05-07 03:41:01', NULL, 46, 8),
('PJ000022', 'ET Cholesterol', 'Box', 190000, 190000, 190000, 7, 2, '2021-05-07 03:41:27', NULL, 46, 8),
('PJ000023', 'ET Uric Asid', 'Box', 165000, 165000, 165000, 12, 2, '2021-05-07 03:41:48', NULL, 46, 8),
('PJ000024', 'Duk Lubang Disposible 50X50cm OM', 'PCS', 28000, 28000, 28000, 12, 2, '2021-05-07 03:42:11', NULL, 46, 8),
('PJ000025', 'Excel Tulle ', 'Box', 158200, 158200, 158200, 12, 2, '2021-05-07 03:42:43', NULL, 46, 8),
('PJ000026', 'Leukoplast Besar', 'Roll', 50000, 50000, 50000, 12, 2, '2021-05-07 03:43:10', NULL, 46, 8),
('PJ000027', 'Leukoplast Kecil', 'Roll', 9000, 9000, 9000, 12, 2, '2021-05-07 03:43:31', NULL, 46, 8),
('PJ000028', 'Needle Terumo No. 23', 'Box', 750000, 75000, 75000, 12, 2, '2021-05-07 03:43:59', NULL, 46, 8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_beli`
--

CREATE TABLE `tbl_beli` (
  `beli_nofak` varchar(15) DEFAULT NULL,
  `beli_tanggal` date DEFAULT NULL,
  `beli_suplier_id` int(11) DEFAULT NULL,
  `beli_user_id` int(11) DEFAULT NULL,
  `beli_kode` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_beli`
--

INSERT INTO `tbl_beli` (`beli_nofak`, `beli_tanggal`, `beli_suplier_id`, `beli_user_id`, `beli_kode`) VALUES
('gvgcdxcf', '2021-05-27', 9, 5, 'BL270521000001');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_detail_beli`
--

CREATE TABLE `tbl_detail_beli` (
  `d_beli_id` int(11) NOT NULL,
  `d_beli_nofak` varchar(15) DEFAULT NULL,
  `d_beli_barang_id` varchar(15) DEFAULT NULL,
  `d_beli_harga` double DEFAULT NULL,
  `d_beli_jumlah` int(11) DEFAULT NULL,
  `d_beli_total` double DEFAULT NULL,
  `d_beli_kode` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_detail_beli`
--

INSERT INTO `tbl_detail_beli` (`d_beli_id`, `d_beli_nofak`, `d_beli_barang_id`, `d_beli_harga`, `d_beli_jumlah`, `d_beli_total`, `d_beli_kode`) VALUES
(3, 'gvgcdxcf', 'PJ000001', 65000, 5, 325000, 'BL270521000001');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_detail_jual`
--

CREATE TABLE `tbl_detail_jual` (
  `d_jual_id` int(11) NOT NULL,
  `d_jual_nofak` varchar(50) DEFAULT NULL,
  `d_jual_barang_id` varchar(15) DEFAULT NULL,
  `d_jual_barang_nama` varchar(150) DEFAULT NULL,
  `d_jual_barang_satuan` varchar(30) DEFAULT NULL,
  `d_jual_barang_harpok` double DEFAULT NULL,
  `d_jual_barang_harjul` double DEFAULT NULL,
  `d_jual_qty` int(11) DEFAULT NULL,
  `d_jual_diskon` double DEFAULT NULL,
  `d_jual_total` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_detail_jual`
--

INSERT INTO `tbl_detail_jual` (`d_jual_id`, `d_jual_nofak`, `d_jual_barang_id`, `d_jual_barang_nama`, `d_jual_barang_satuan`, `d_jual_barang_harpok`, `d_jual_barang_harjul`, `d_jual_qty`, `d_jual_diskon`, `d_jual_total`) VALUES
(20, 'ARP/080521000001', 'PJ000004', 'Infuset Y-Injection site', 'PCS', 7418, 7418, 4, 0, 29672),
(21, 'ARP/080521000001', 'PJ000002', 'Spuit 10cc OM', 'Kotak', 86250, 86250, 3, 0, 258750),
(22, 'ARP/080521000001', 'PJ000001', 'ID Band Dewasa Pink', 'PCS', 65000, 65000, 2, 0, 130000),
(23, 'ARP/080521000001', 'PJ000010', 'Atramat PGA 2-0 RC 40mm 90cm', 'PCS', 90000, 90000, 5, 0, 450000),
(24, 'ARP/080521000001', 'PJ000011', 'Atramat Plain 0 TP 40mm 75cm', 'PCS', 42500, 42500, 4, 0, 170000),
(25, 'ARP/080521000002', 'PJ000013', 'Surgisilk 2-0 TP26', 'PCS', 50000, 50000, 3, 0, 150000),
(26, 'ARP/080521000002', 'PJ000015', 'Jarum Mani MH28', 'Pack', 90000, 90000, 6, 0, 540000),
(27, 'ARP/080521000002', 'PJ000016', 'Jarum Mani MH32', 'Pack', 90000, 90000, 3, 0, 270000),
(28, 'ARP/080521000002', 'PJ000020', 'Jarum Mani MH55', 'PCS', 8250, 8250, 4, 0, 33000),
(29, 'ARP/080521000002', 'PJ000022', 'ET Cholesterol', 'Box', 190000, 190000, 5, 0, 950000),
(30, 'ARP/270521000001', 'PJ000001', 'ID Band Dewasa Pink', 'PCS', 65000, 65000, 1, 0, 65000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_jual`
--

CREATE TABLE `tbl_jual` (
  `jual_nofak` varchar(50) NOT NULL,
  `jual_tanggal` timestamp NULL DEFAULT current_timestamp(),
  `jual_total` double DEFAULT NULL,
  `jual_jml_uang` double DEFAULT NULL,
  `jual_kembalian` double DEFAULT NULL,
  `jual_user_id` int(11) DEFAULT NULL,
  `jual_keterangan` varchar(20) DEFAULT NULL,
  `jual_pembeli` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_jual`
--

INSERT INTO `tbl_jual` (`jual_nofak`, `jual_tanggal`, `jual_total`, `jual_jml_uang`, `jual_kembalian`, `jual_user_id`, `jual_keterangan`, `jual_pembeli`) VALUES
('ARP/080521000001', '2021-05-08 13:17:28', 1038422, 1100000, 61578, 5, 'grosir', 'RS PKU Muhammadiyah Surakarta'),
('ARP/080521000002', '2021-05-08 13:19:15', 1943000, 2060000, 117000, 5, 'eceran', 'RS BUDI JAYA'),
('ARP/270521000001', '2021-05-27 07:02:37', 65000, 70000, 5000, 5, 'eceran', 'RS BUDI JAYA');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kategori`
--

CREATE TABLE `tbl_kategori` (
  `kategori_id` int(11) NOT NULL,
  `kategori_nama` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_kategori`
--

INSERT INTO `tbl_kategori` (`kategori_id`, `kategori_nama`) VALUES
(46, 'alat kesehatan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pelanggan`
--

CREATE TABLE `tbl_pelanggan` (
  `pelanggan_id` varchar(15) NOT NULL,
  `pelanggan_nama` varchar(50) NOT NULL,
  `pelanggan_alamat` varchar(50) NOT NULL,
  `pelanggan_notlpn` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_retur`
--

CREATE TABLE `tbl_retur` (
  `retur_id` int(11) NOT NULL,
  `retur_tanggal` timestamp NULL DEFAULT current_timestamp(),
  `retur_barang_id` varchar(15) DEFAULT NULL,
  `retur_barang_nama` varchar(150) DEFAULT NULL,
  `retur_barang_satuan` varchar(30) DEFAULT NULL,
  `retur_harjul` double DEFAULT NULL,
  `retur_qty` int(11) DEFAULT NULL,
  `retur_subtotal` double DEFAULT NULL,
  `retur_keterangan` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_suplier`
--

CREATE TABLE `tbl_suplier` (
  `suplier_id` int(11) NOT NULL,
  `suplier_nama` varchar(35) DEFAULT NULL,
  `suplier_alamat` varchar(60) DEFAULT NULL,
  `suplier_notelp` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_suplier`
--

INSERT INTO `tbl_suplier` (`suplier_id`, `suplier_nama`, `suplier_alamat`, `suplier_notelp`) VALUES
(9, 'tdvhj', 'Solo', '0832568868');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `user_nama` varchar(35) DEFAULT NULL,
  `user_username` varchar(30) DEFAULT NULL,
  `user_password` varchar(35) DEFAULT NULL,
  `user_level` varchar(2) DEFAULT NULL,
  `user_status` varchar(2) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_nama`, `user_username`, `user_password`, `user_level`, `user_status`) VALUES
(5, 'admin', 'admin', '202cb962ac59075b964b07152d234b70', '1', '1'),
(6, 'Luqman Hanung Asidiq', 'luqmanhanung', '202cb962ac59075b964b07152d234b70', '2', '1'),
(7, 'Aisyah Goevara', 'goevara', '202cb962ac59075b964b07152d234b70', '3', '1'),
(8, 'Veny Fitriana Isnaini', 'venyfitrianais', '202cb962ac59075b964b07152d234b70', '1', '1');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_barang`
--
ALTER TABLE `tbl_barang`
  ADD PRIMARY KEY (`barang_id`),
  ADD KEY `barang_user_id` (`barang_user_id`),
  ADD KEY `barang_kategori_id` (`barang_kategori_id`);

--
-- Indeks untuk tabel `tbl_beli`
--
ALTER TABLE `tbl_beli`
  ADD PRIMARY KEY (`beli_kode`),
  ADD KEY `beli_user_id` (`beli_user_id`),
  ADD KEY `beli_suplier_id` (`beli_suplier_id`),
  ADD KEY `beli_id` (`beli_kode`);

--
-- Indeks untuk tabel `tbl_detail_beli`
--
ALTER TABLE `tbl_detail_beli`
  ADD PRIMARY KEY (`d_beli_id`),
  ADD KEY `d_beli_barang_id` (`d_beli_barang_id`),
  ADD KEY `d_beli_nofak` (`d_beli_nofak`),
  ADD KEY `d_beli_kode` (`d_beli_kode`);

--
-- Indeks untuk tabel `tbl_detail_jual`
--
ALTER TABLE `tbl_detail_jual`
  ADD PRIMARY KEY (`d_jual_id`),
  ADD KEY `d_jual_barang_id` (`d_jual_barang_id`),
  ADD KEY `d_jual_nofak` (`d_jual_nofak`);

--
-- Indeks untuk tabel `tbl_jual`
--
ALTER TABLE `tbl_jual`
  ADD PRIMARY KEY (`jual_nofak`),
  ADD KEY `jual_user_id` (`jual_user_id`);

--
-- Indeks untuk tabel `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
  ADD PRIMARY KEY (`kategori_id`);

--
-- Indeks untuk tabel `tbl_pelanggan`
--
ALTER TABLE `tbl_pelanggan`
  ADD PRIMARY KEY (`pelanggan_id`) USING BTREE;

--
-- Indeks untuk tabel `tbl_retur`
--
ALTER TABLE `tbl_retur`
  ADD PRIMARY KEY (`retur_id`);

--
-- Indeks untuk tabel `tbl_suplier`
--
ALTER TABLE `tbl_suplier`
  ADD PRIMARY KEY (`suplier_id`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_detail_beli`
--
ALTER TABLE `tbl_detail_beli`
  MODIFY `d_beli_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tbl_detail_jual`
--
ALTER TABLE `tbl_detail_jual`
  MODIFY `d_jual_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT untuk tabel `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
  MODIFY `kategori_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT untuk tabel `tbl_retur`
--
ALTER TABLE `tbl_retur`
  MODIFY `retur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tbl_suplier`
--
ALTER TABLE `tbl_suplier`
  MODIFY `suplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tbl_barang`
--
ALTER TABLE `tbl_barang`
  ADD CONSTRAINT `tbl_barang_ibfk_1` FOREIGN KEY (`barang_user_id`) REFERENCES `tbl_user` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_barang_ibfk_2` FOREIGN KEY (`barang_kategori_id`) REFERENCES `tbl_kategori` (`kategori_id`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_beli`
--
ALTER TABLE `tbl_beli`
  ADD CONSTRAINT `tbl_beli_ibfk_1` FOREIGN KEY (`beli_user_id`) REFERENCES `tbl_user` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_beli_ibfk_2` FOREIGN KEY (`beli_suplier_id`) REFERENCES `tbl_suplier` (`suplier_id`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_detail_beli`
--
ALTER TABLE `tbl_detail_beli`
  ADD CONSTRAINT `tbl_detail_beli_ibfk_1` FOREIGN KEY (`d_beli_barang_id`) REFERENCES `tbl_barang` (`barang_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_detail_beli_ibfk_2` FOREIGN KEY (`d_beli_kode`) REFERENCES `tbl_beli` (`beli_kode`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_detail_jual`
--
ALTER TABLE `tbl_detail_jual`
  ADD CONSTRAINT `tbl_detail_jual_ibfk_1` FOREIGN KEY (`d_jual_barang_id`) REFERENCES `tbl_barang` (`barang_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_detail_jual_ibfk_2` FOREIGN KEY (`d_jual_nofak`) REFERENCES `tbl_jual` (`jual_nofak`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_jual`
--
ALTER TABLE `tbl_jual`
  ADD CONSTRAINT `tbl_jual_ibfk_1` FOREIGN KEY (`jual_user_id`) REFERENCES `tbl_user` (`user_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
